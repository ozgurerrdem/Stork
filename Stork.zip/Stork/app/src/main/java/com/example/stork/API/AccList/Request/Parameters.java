package com.example.stork.API.AccList.Request;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Parameters {
    @SerializedName("CustomerNo")
    @Expose
    public String customerNo;

}
