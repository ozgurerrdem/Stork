package com.example.stork.API.ProcessScheduledTransactionForIbanEft.Response;

import com.google.gson.annotations.SerializedName;

public class Data {

    @SerializedName("State")
    public String state;

}