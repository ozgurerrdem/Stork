package com.example.stork.Model;

public class CardModel {
    public int card;

    public CardModel(int card) {
        this.card = card;
    }
    public int getCard(){
        return card;
    }
}
